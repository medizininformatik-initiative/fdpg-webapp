module.exports = {
  preset: '@vue/cli-plugin-unit-jest/presets/typescript-and-babel',
  testMatch: ['**/*.spec.ts'],
  setupFilesAfterEnv: ['<rootDir>/src/__test__/jest.setupTests.ts'],
  moduleNameMapper: {
    '^lodash-es$': 'lodash',
  },
  collectCoverage: true,
  coverageReporters: ['text', 'cobertura', 'html', 'lcov'],
  coverageDirectory: 'reports/coverage',
  reporters: [
    'default',
    [
      'jest-junit',
      {
        outputDirectory: 'reports',
        outputName: 'junit.xml',
      },
    ],
  ],
  collectCoverageFrom: [
    'src/**/*.{js,jsx,ts,tsx,vue}',
    // do not cover types declarations
    '!src/**/*.d.ts',

    '!**/__mocks__/**',
    '!**/__tests__/**',
    '!**/__test__/**',
    '!**/*.spec.ts',
    '!**/*.mock.ts',

    '!src/main.ts',
    '!src/locales/**',
    '!src/router/routes.ts',
    '!src/router/index.ts',

    // Libs where we assume that they are tested by the maintainer
    '!src/libs/**',
  ],
}
