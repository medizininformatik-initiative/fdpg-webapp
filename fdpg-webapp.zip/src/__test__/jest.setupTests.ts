import { config } from '@vue/test-utils'

config.global.mocks = {
  $t: () => {},
}

window.open = jest.fn()

Object.defineProperty(URL, 'revokeObjectURL', {
  value: () => {},
})
