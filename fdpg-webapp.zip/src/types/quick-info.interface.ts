export interface IQuickInfo {
  icon: string
  label: string
  values: (string | number)[]
  fullSize?: boolean
}
