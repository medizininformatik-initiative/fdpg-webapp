import { IButtonConfig } from './button-config.interface'

export interface IDetailActionRow extends IButtonConfig {
  position: 'left' | 'right'
}
