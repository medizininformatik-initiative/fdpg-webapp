export enum PlatformIdentifier {
  Mii = 'MII',
}
