export interface IVersion {
  mayor: number
  minor: number
}
