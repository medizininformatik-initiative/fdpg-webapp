export interface IFeasibilityDetail {
  id: number
  label: string
  createdAt: string
}
