export enum Salutation {
  Female = 'FEMALE',
  Male = 'MALE',
  Neutral = 'NEUTRAL',
}
