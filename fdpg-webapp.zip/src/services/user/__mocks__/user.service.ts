export const mockCreate = jest.fn()
export const mockUpdateProfile = jest.fn()
export const mockResendInvitation = jest.fn()
export const mockResetPassword = jest.fn()
export const UserService = jest.fn().mockImplementation(() => ({
  create: mockCreate,
  updateProfile: mockUpdateProfile,
  resendInvitation: mockResendInvitation,
  resetPassword: mockResetPassword,
}))
