import { UserService } from '@/services/user/user.service'
import { ApiClient } from '@/httpClients/api/api.client'
import { AxiosInstance } from 'axios'
import { ParticipantType } from '@/types/proposal.types'
import { Role } from '@/types/oidc.types'
import { ICreateUser } from '@/types/user.types'
import { Salutation } from '@/types/salutation.enum'

jest.mock('@/httpClients/api/api.client')

describe('UserService', () => {
  let service: UserService
  let apiClient: AxiosInstance
  const basePath = '/users'

  beforeEach(() => {
    apiClient = new ApiClient().client
    jest.clearAllMocks()
    service = new UserService()
  })

  it('should create user', async () => {
    jest.spyOn(apiClient, 'post').mockResolvedValue(undefined)
    const user = {
      title: 'string',
      firstName: 'string',
      lastName: 'string',
      affiliation: 'string',
      email: 'string',
      isExisting: true,
      isEmailVerified: true,
      isRegistrationComplete: true,
      participantType: ParticipantType.AdditionalProjectLeader,
      username: 'string',
    }
    const createPayload = {
      redirectUri: window.location.origin,
      clientId: process.env.VUE_APP_KEYCLOAK_CLIENT_ID as string,
      role: Role.Researcher,

      email: user.email,
      username: user.username,
      firstName: user.firstName,
      lastName: user.lastName,
    } as ICreateUser
    await service.create(user)
    expect(apiClient.post).toHaveBeenCalledWith(`${basePath}`, createPayload)
  })

  it('should update profile', async () => {
    jest.spyOn(apiClient, 'put').mockResolvedValue(undefined)
    const user = {
      salutation: Salutation.Female,
      title: 'string',
      firstName: 'string',
      lastName: 'string',
      email: 'string',
      affiliation: 'string',
    }

    const userId = 'userId'
    await service.updateProfile(userId, user)
    expect(apiClient.put).toHaveBeenCalledWith(`${basePath}/${userId}`, user)
  })

  it('should resend invitation', async () => {
    jest.spyOn(apiClient, 'patch').mockResolvedValue(undefined)
    const email = 'email'
    const resendPayload = {
      redirectUri: window.location.origin,
      clientId: process.env.VUE_APP_KEYCLOAK_CLIENT_ID as string,
      email,
    }
    await service.resendInvitation(email)
    expect(apiClient.patch).toHaveBeenCalledWith(`${basePath}/resend-invitation`, resendPayload)
  })

  it('should reset password', async () => {
    jest.spyOn(apiClient, 'put').mockResolvedValue(undefined)
    const resendPayload = {
      redirectUri: `${window.location.origin}/profile`,
      clientId: process.env.VUE_APP_KEYCLOAK_CLIENT_ID as string,
    }
    const userId = 'userId'
    await service.resetPassword(userId)
    expect(apiClient.put).toHaveBeenCalledWith(`${basePath}/${userId}/password-reset`, resendPayload)
  })
})
