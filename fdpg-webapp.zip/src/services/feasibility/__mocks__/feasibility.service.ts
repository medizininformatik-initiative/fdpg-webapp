export const mockGetAll = jest.fn()

export const FeasibilityService = jest.fn().mockImplementation(() => ({
  getAll: mockGetAll,
}))
