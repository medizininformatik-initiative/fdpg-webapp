import { ApiClient } from '@/httpClients/api/api.client'
import { AxiosInstance } from 'axios'
import { FeasibilityService } from './feasibility.service'

jest.mock('@/httpClients/api/api.client')

const mockGetAllResponse = {
  data: 'Hello World',
}

describe('FeasibilityService', () => {
  let service: FeasibilityService
  let apiClient: AxiosInstance
  const basePath = '/feasibilities'

  beforeEach(() => {
    apiClient = new ApiClient().client
    jest.clearAllMocks()
    service = new FeasibilityService()
  })

  describe('GetAll', () => {
    it('should call the api client to get all feasibility queries of the user', async () => {
      jest.spyOn(apiClient, 'get').mockResolvedValue(mockGetAllResponse)
      const response = await service.getAll()
      expect(apiClient.get).toHaveBeenCalledWith(`${basePath}`)
      expect(response).toEqual(mockGetAllResponse.data)
    })
  })
})
