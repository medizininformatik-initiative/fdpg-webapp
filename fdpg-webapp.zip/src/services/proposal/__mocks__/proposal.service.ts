export const mockGetAll = jest.fn()
export const mockCreate = jest.fn()
export const mockGet = jest.fn()
export const mockUpdate = jest.fn()
export const mockUpdateStatus = jest.fn()
export const mockDelete = jest.fn()
export const mockUpdateLockingState = jest.fn()
export const mockSetUacVote = jest.fn()
export const mockMarkUacConditionAsAccepted = jest.fn()
export const mockSetDizApproval = jest.fn()
export const mockSignContract = jest.fn()
export const mockInitContracting = jest.fn()
export const mockUploadFile = jest.fn()
export const mockRemoveFile = jest.fn()
export const mockGetDownloadUrl = jest.fn()
export const mockGetResearcherInfo = jest.fn()
export const mockDeleteProposal = jest.fn()
export const mockDuplicate = jest.fn()
export const mockCheckUnique = jest.fn()
export const mockMarkSectionAsDone = jest.fn()
export const mockCreatePublication = jest.fn()
export const mockUpdatePublication = jest.fn()
export const mockDeletePublication = jest.fn()
export const mockGetReports = jest.fn()
export const mockGetReportContent = jest.fn()
export const mockCreateReport = jest.fn()
export const mockUpdateReport = jest.fn()
export const mockDeleteReport = jest.fn()
export const mockUpdateFdpgChecklist = jest.fn()
export const ProposalService = jest.fn().mockImplementation(() => ({
  getAll: mockGetAll,
  create: mockCreate,
  get: mockGet,
  update: mockUpdate,
  updateStatus: mockUpdateStatus,
  updateLockingState: mockUpdateLockingState,
  delete: mockDelete,
  setUacVote: mockSetUacVote,
  markUacConditionAsAccepted: mockMarkUacConditionAsAccepted,
  setDizApproval: mockSetDizApproval,
  signContract: mockSignContract,
  initContracting: mockInitContracting,
  uploadFile: mockUploadFile,
  removeFile: mockRemoveFile,
  getDownloadUrl: mockGetDownloadUrl,
  getResearcherInfo: mockGetResearcherInfo,
  deleteProposal: mockDeleteProposal,
  duplicate: mockDuplicate,
  checkUnique: mockCheckUnique,
  markSectionAsDone: mockMarkSectionAsDone,
  createPublication: mockCreatePublication,
  updatePublication: mockUpdatePublication,
  deletePublication: mockDeletePublication,
  getReports: mockGetReports,
  getReportContent: mockGetReportContent,
  createReport: mockCreateReport,
  updateReport: mockUpdateReport,
  deleteReport: mockDeleteReport,
  updateFdpgChecklist: mockUpdateFdpgChecklist,
}))
