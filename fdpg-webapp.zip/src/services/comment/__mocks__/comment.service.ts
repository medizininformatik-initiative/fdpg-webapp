export const mockGetAll = jest.fn()
export const mockCreate = jest.fn()
export const mockCreateAnswer = jest.fn()
export const mockUpdate = jest.fn()
export const mockMarkCommentAsDone = jest.fn()
export const mockMarkAnswerAsDone = jest.fn()
export const mockDelete = jest.fn()

export const CommentService = jest.fn().mockImplementation(() => ({
  getAll: mockGetAll,
  create: mockCreate,
  createAnswer: mockCreateAnswer,
  update: mockUpdate,
  markCommentAsDone: mockMarkCommentAsDone,
  markAnswerAsDone: mockMarkAnswerAsDone,
  delete: mockDelete,
}))
