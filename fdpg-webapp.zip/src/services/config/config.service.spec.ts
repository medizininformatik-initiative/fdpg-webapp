import { ApiClient } from '@/httpClients/api/api.client'
import { PlatformIdentifier } from '@/types/platform-identifier.enum'
import { AxiosInstance } from 'axios'
import { ConfigService } from './config.service'

jest.mock('@/httpClients/api/api.client')

const mockGetAllResponse = {
  data: 'Hello World',
}

describe('ConfigService', () => {
  let service: ConfigService
  let apiClient: AxiosInstance
  const basePath = '/config'

  beforeEach(() => {
    apiClient = new ApiClient().client
    jest.clearAllMocks()
    service = new ConfigService()
  })

  describe('GetTermsAndConditions', () => {
    it('should call the api client to get the terms and conditions of the platform', async () => {
      jest.spyOn(apiClient, 'get').mockResolvedValue(mockGetAllResponse)
      const response = await service.getTermsAndConditions(PlatformIdentifier.Mii)
      expect(apiClient.get).toHaveBeenCalledWith(`${basePath}/${PlatformIdentifier.Mii}/terms`)
      expect(response).toEqual(mockGetAllResponse.data)
    })
  })

  it('should get data privacy', async () => {
    jest.spyOn(apiClient, 'get').mockResolvedValue(mockGetAllResponse)
    const response = await service.getDataPrivacy(PlatformIdentifier.Mii)
    expect(apiClient.get).toHaveBeenCalledWith(`${basePath}/${PlatformIdentifier.Mii}/type-of-use-data-privacy`)
    expect(response).toEqual(mockGetAllResponse.data)
  })
})
