export const mockGetTermsAndConditions = jest.fn()
export const mockGetDataPrivacy = jest.fn()
export const ConfigService = jest.fn().mockImplementation(() => ({
  getTermsAndConditions: mockGetTermsAndConditions,
  getDataPrivacy: mockGetDataPrivacy,
}))
