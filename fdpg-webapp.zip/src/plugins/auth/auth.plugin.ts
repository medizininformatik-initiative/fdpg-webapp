import { createOidcAuth, SignInType, LogLevel } from 'vue-oidc-client/vue3'
import { App } from 'vue'
import { LocationUtil } from '@/utils/location.util'
import { Router } from 'vue-router'
import { WebStorageStateStore } from 'oidc-client'
import { addRoleGuard } from './role.guard'

export const initAuthPlugin = async (router: Router) => {
  const location = new LocationUtil()

  const mainOidc = createOidcAuth(
    'main',
    SignInType.Window,
    location.baseUrl,
    {
      authority: `${process.env.VUE_APP_KEYCLOAK_BASE_URL}/auth/realms/${process.env.VUE_APP_KEYCLOAK_REALM}`,
      client_id: process.env.VUE_APP_KEYCLOAK_CLIENT_ID,
      response_type: 'code',
      scope: 'openid profile email roles',
      automaticSilentRenew: true,
      mergeClaims: true,
      loadUserInfo: true,
      monitorSession: false,
      userStore: new WebStorageStateStore({ store: localStorage }),
    },
    console,
    process.env.NODE_ENV === 'development' ? LogLevel.Warn : LogLevel.Error,
  )

  mainOidc.useRouter(router)
  addRoleGuard(router)

  const isOidcStartupOkay = await mainOidc.startup()

  if (!isOidcStartupOkay) {
    throw new Error('Init Auth failed')
  }

  const install = (app: App) => {
    app.config.globalProperties.$oidc = mainOidc
  }

  return {
    install,
    mainOidc,
  }
}
