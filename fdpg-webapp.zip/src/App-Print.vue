<template>
  <router-view />
</template>

<script setup lang="ts">
import 'element-theme-chalk'
</script>
