const mockFetch = jest.fn()
const mockCreateProposal = jest.fn()
const mockSetCurrentProposal = jest.fn()
const mockUpdateProposal = jest.fn()
const mockUpdateProposalStatus = jest.fn()
const mockUpdateLockingState = jest.fn()
const mockSetUacVote = jest.fn()
const mockMarkUacConditionAsAccepted = jest.fn()
const mockSetDizApproval = jest.fn()
const mockSignContract = jest.fn()
const mockUploadFile = jest.fn()
const mockRemoveUpload = jest.fn()
const mockGetDownloadUrl = jest.fn()
const mockGetResearcherInfo = jest.fn()
const mockDeleteProposal = jest.fn()
const mockDuplicateProposal = jest.fn()
const mockCheckUnique = jest.fn()
const mockUpdateFdpgChecklist = jest.fn()
const mockMarkSectionAsDone = jest.fn()
const mockSetSortField = jest.fn()
const mockToggleSortDirection = jest.fn()

export const useProposalStore = jest.fn().mockImplementation(() => ({
  proposals: {},
  currentProposal: undefined,
  counts: {},
  _checkListLastSuccess: {},

  //Actions
  fetch: mockFetch,
  createProposal: mockCreateProposal,
  setCurrentProposal: mockSetCurrentProposal,
  updateProposal: mockUpdateProposal,
  updateLockingState: mockUpdateLockingState,
  updateProposalStatus: mockUpdateProposalStatus,
  setUacVote: mockSetUacVote,
  markUacConditionAsAccepted: mockMarkUacConditionAsAccepted,
  setDizApproval: mockSetDizApproval,
  signContract: mockSignContract,
  uploadFile: mockUploadFile,
  removeUpload: mockRemoveUpload,
  getDownloadUrl: mockGetDownloadUrl,
  getResearcherInfo: mockGetResearcherInfo,
  deleteProposal: mockDeleteProposal,
  duplicateProposal: mockDuplicateProposal,
  checkUnique: mockCheckUnique,
  updateFdpgChecklist: mockUpdateFdpgChecklist,
  markSectionAsDone: mockMarkSectionAsDone,
  setSortField: mockSetSortField,
  toggleSortDirection: mockToggleSortDirection,
}))
