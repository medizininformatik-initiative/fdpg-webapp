import { mockProposalDetail, mockProposal } from '@/mocks/proposal.mock'
import { ProposalService } from '@/services/proposal/proposal.service'
import { createPinia, setActivePinia } from 'pinia'
import { useProposalStore } from './proposal.store'
import { ISortAndOrderBy, PanelQuery, SortDirection } from '@/types/sort-filter.types'
import { transformForm } from '@/utils/form-transform'
import {
  IProposal,
  IPublicationCreateAndUpdate,
  IPublicationGet,
  IReportCreate,
  IResearcherIdentity,
  IUpload,
  IReportUpdate,
  IReportGet,
  ParticipantType,
  ProposalStatus,
  IFdpgChecklist,
} from '@/types/proposal.types'
import { IDeclineUacApproval } from '@/types/uac-approval.types'
import { IDizApproval } from '@/types/diz-approval.types'
import { IDeclineContract } from '@/types/sign-contract.types'
import { DirectUpload, UseCaseUpload } from '@/types/upload.types'
import { setImmediate } from 'timers'

jest.mock('@/services/proposal/proposal.service')

const proposalService = jest.mocked(new ProposalService())

describe('Proposal Store', () => {
  beforeEach(() => {
    jest.clearAllMocks()
    setActivePinia(createPinia())
    jest.useFakeTimers()
  })

  it('renders', () => {
    const store = useProposalStore()
    expect(store).toBeTruthy()
  })

  describe('GetAll', () => {
    it('should call the service to get all proposals', async () => {
      const store = useProposalStore()
      jest.mocked(proposalService.getAll).mockResolvedValue([mockProposalDetail])
      await store.fetch({ panelQuery: PanelQuery.Archived } as ISortAndOrderBy<any>)
      expect(proposalService.getAll).toHaveBeenCalledWith({ panelQuery: PanelQuery.Archived } as ISortAndOrderBy<any>)
      expect(store.proposals).toEqual({ [PanelQuery.Archived]: [mockProposalDetail] })
      expect(store.counts).toEqual({ ARCHIVED: { critical: 1, high: 0, low: 0, total: 1 } })
    })
  })

  it('should call the service to create a proposal', async () => {
    const store = useProposalStore()
    jest.spyOn(proposalService, 'create').mockResolvedValue(mockProposal)
    await store.createProposal(mockProposal)
    expect(proposalService.create).toHaveBeenCalledWith(mockProposal)
  })

  it('should call the service to set current proposal', async () => {
    const store = useProposalStore()
    jest.spyOn(proposalService, 'get').mockResolvedValue(mockProposal)
    const proposalId = 'proposalId'
    await store.setCurrentProposal(proposalId)
    expect(proposalService.get).toHaveBeenCalledWith(proposalId)
    expect(store.currentProposal).toEqual(transformForm(mockProposal) as IProposal)
  })

  it('should call the service to set current proposal to nothing', async () => {
    const store = useProposalStore()
    jest.spyOn(proposalService, 'get').mockResolvedValue(mockProposal)
    await store.setCurrentProposal()
    expect(store.currentProposal).toEqual(transformForm() as IProposal)
  })

  it('should call the service to update proposal', async () => {
    const store = useProposalStore()
    jest.spyOn(proposalService, 'update').mockResolvedValue(mockProposal)
    const proposalId = 'proposalId'
    await store.updateProposal(proposalId, mockProposal)
    expect(proposalService.update).toHaveBeenCalledWith(proposalId, mockProposal)
  })

  it('should call the service to update proposal status', async () => {
    const store = useProposalStore()
    jest.spyOn(proposalService, 'updateStatus').mockResolvedValue(mockProposal)
    const status = ProposalStatus.Archived
    const proposalId = 'proposalId'
    await store.updateProposalStatus(proposalId, status)
    expect(proposalService.updateStatus).toHaveBeenCalledWith(proposalId, status)
  })

  it('should call the service to update proposal locking state', async () => {
    const store = useProposalStore()
    jest.spyOn(proposalService, 'updateLockingState').mockResolvedValue(mockProposal)
    const lockingState = true
    const proposalId = 'proposalId'
    await store.updateLockingState(proposalId, lockingState)
    expect(proposalService.updateLockingState).toHaveBeenCalledWith(proposalId, lockingState)
  })

  it('should call the service to setUacVote', async () => {
    const store = useProposalStore()
    jest.spyOn(proposalService, 'setUacVote').mockResolvedValue()
    const decision = { value: false, declineReason: 'string' } as IDeclineUacApproval
    const proposalId = 'proposalId'
    await store.setUacVote(proposalId, decision)
    expect(proposalService.setUacVote).toHaveBeenCalledWith(proposalId, decision)
  })

  it('should call the service to markUacConditionAsAccepted', async () => {
    const store = useProposalStore()
    jest.spyOn(proposalService, 'markUacConditionAsAccepted').mockResolvedValue(mockProposal)
    const conditionId = 'conditionId'
    const proposalId = 'proposalId'
    await store.markUacConditionAsAccepted(proposalId, conditionId, true)
    expect(proposalService.markUacConditionAsAccepted).toHaveBeenCalledWith(proposalId, conditionId, true)
  })

  it('should call the service to markUacConditionAsAccepted in current proposal', async () => {
    const store = useProposalStore()
    store.currentProposal = mockProposal
    jest.spyOn(proposalService, 'markUacConditionAsAccepted').mockResolvedValue(mockProposal)
    const conditionId = 'conditionId'
    const proposalId = '630dd9e8c8a548d21ef4c356'
    await store.markUacConditionAsAccepted(proposalId, conditionId, true)
    expect(proposalService.markUacConditionAsAccepted).toHaveBeenCalledWith(proposalId, conditionId, true)
    expect(store.currentProposal).toEqual(mockProposal)
  })

  it('should call the service to set diz approval', async () => {
    const store = useProposalStore()
    jest.spyOn(proposalService, 'setDizApproval').mockResolvedValue()
    const decision = { value: true } as IDizApproval
    const proposalId = 'proposalId'
    await store.setDizApproval(proposalId, decision)
    expect(proposalService.setDizApproval).toHaveBeenCalledWith(proposalId, decision)
  })

  it('should call the service to sign contract', async () => {
    const store = useProposalStore()
    jest.spyOn(proposalService, 'signContract').mockResolvedValue(mockProposal)
    const decision = {
      value: false,
      declineReason: 'string',
    } as IDeclineContract
    const proposalId = 'proposalId'
    await store.signContract(proposalId, decision)
    expect(proposalService.signContract).toHaveBeenCalledWith(proposalId, decision)
  })

  it('should call the service to init contracting', async () => {
    const store = useProposalStore()
    jest.spyOn(proposalService, 'initContracting').mockResolvedValue(mockProposal)
    const file = new File([new Blob(['1'], { type: 'image/png' })], 'test.png')
    const proposalId = 'proposalId'
    await store.initContracting(proposalId, file)
    expect(proposalService.initContracting).toHaveBeenCalledWith(proposalId, file)
  })

  it('should call the service to uploadFile', async () => {
    const store = useProposalStore()
    store.currentProposal = mockProposal
    jest.spyOn(proposalService, 'uploadFile').mockResolvedValue({
      fileName: 'string',
      fileSize: 3,
      type: DirectUpload.EthicVote,
      createdAt: 'string',
      _id: 'string',
    } as IUpload)
    const file = new File([new Blob(['1'], { type: 'image/png' })], 'test.png')
    const proposalId = 'proposalId'
    await store.uploadFile(proposalId, file, DirectUpload.EthicVote)
    expect(proposalService.uploadFile).toHaveBeenCalledWith(proposalId, file, DirectUpload.EthicVote)
    let uploads = mockProposal.uploads || []
    uploads.push({
      fileName: 'string',
      fileSize: 3,
      type: DirectUpload.EthicVote,
      createdAt: 'string',
      _id: 'string',
    } as IUpload)
    expect(store.currentProposal.uploads).toEqual(uploads)
  })

  it('should call the service to removeUpload', async () => {
    const store = useProposalStore()
    store.currentProposal = mockProposal
    jest.spyOn(proposalService, 'removeFile').mockResolvedValue()
    const uploadId = 'UploadId1'
    const proposalId = 'proposalId'
    await store.removeUpload(proposalId, uploadId)
    let uploads = mockProposal.uploads || []
    uploads = uploads.filter((upload) => upload._id !== uploadId)
    expect(proposalService.removeFile).toHaveBeenCalledWith(proposalId, uploadId)
    expect(store.currentProposal.uploads).toEqual(uploads)
  })

  it('should call the service to getDownloadUrl', async () => {
    const store = useProposalStore()
    jest.spyOn(proposalService, 'getDownloadUrl').mockResolvedValue('string')
    const uploadId = 'uploadId'
    const proposalId = 'proposalId'
    await store.getDownloadUrl(proposalId, uploadId)
    expect(proposalService.getDownloadUrl).toHaveBeenCalledWith(proposalId, uploadId)
  })

  it('should call the service to uploadFile for proposal that is empty of uploads', async () => {
    const store = useProposalStore()
    store.currentProposal = mockProposal
    store.currentProposal.uploads = undefined
    jest.spyOn(proposalService, 'uploadFile').mockResolvedValue({
      fileName: 'string',
      fileSize: 3,
      type: DirectUpload.EthicVote,
      createdAt: 'string',
      _id: 'string',
    } as IUpload)
    const file = new File([new Blob(['1'], { type: 'image/png' })], 'test.png')
    const proposalId = 'proposalId'
    await store.uploadFile(proposalId, file, DirectUpload.EthicVote)
    expect(proposalService.uploadFile).toHaveBeenCalledWith(proposalId, file, DirectUpload.EthicVote)
    const uploads = [
      {
        fileName: 'string',
        fileSize: 3,
        type: DirectUpload.EthicVote,
        createdAt: 'string',
        _id: 'string',
      },
    ] as unknown as IUpload
    expect(store.currentProposal.uploads).toEqual(uploads)
  })

  it('should call the service to getResearcherInfo', async () => {
    const store = useProposalStore()
    jest.spyOn(proposalService, 'getResearcherInfo').mockResolvedValue([
      {
        title: 'string',
        firstName: 'string',
        lastName: 'string',
        affiliation: 'string',
        email: 'string',
        isExisting: true,
        isEmailVerified: true,
        isRegistrationComplete: true,
        participantType: ParticipantType.AdditionalProjectLeader,
        username: 'string',
      },
    ] as IResearcherIdentity[])
    const proposalId = 'proposalId'
    await store.getResearcherInfo(proposalId)
    expect(proposalService.getResearcherInfo).toHaveBeenCalledWith(proposalId)
  })

  it('should call the service to deleteProposal', async () => {
    const store = useProposalStore()
    store.proposals = { [PanelQuery.Archived]: [mockProposalDetail] }
    jest.spyOn(proposalService, 'delete').mockResolvedValue()
    const proposalId = 'proposalId'
    expect(store.proposals[PanelQuery.Archived]?.length).toEqual(1)
    await store.deleteProposal(proposalId, PanelQuery.Archived)
    expect(proposalService.delete).toHaveBeenCalledWith(proposalId)
    expect(store.proposals[PanelQuery.Archived]).toEqual([])
  })

  it('should call the service to duplicateProposal', async () => {
    const store = useProposalStore()
    jest.spyOn(proposalService, 'duplicate').mockResolvedValue(mockProposal)
    const proposalId = 'proposalId'
    await store.duplicateProposal(proposalId)
    expect(proposalService.duplicate).toHaveBeenCalledWith(proposalId)
  })

  it('should call the service to checkUnique', async () => {
    const store = useProposalStore()
    jest.spyOn(proposalService, 'checkUnique').mockResolvedValue(true)
    const proposalId = 'proposalId'
    const value = 'string'
    await store.checkUnique(value, proposalId)
    expect(proposalService.checkUnique).toHaveBeenCalledWith(value, proposalId)
  })

  it('should call the service to markSectionAsDone', async () => {
    const store = useProposalStore()
    jest.spyOn(proposalService, 'markSectionAsDone').mockResolvedValue()
    const proposalId = 'proposalId'
    const sectionId = 'sectionId'
    const value = true
    await store.markSectionAsDone(proposalId, sectionId, value)
    expect(proposalService.markSectionAsDone).toHaveBeenCalledWith(proposalId, sectionId, value)
  })

  it('should set sort field', async () => {
    const store = useProposalStore()
    store.currentSortField = 'submittedAt'
    await store.setSortField('projectAbbreviation')
    expect(store.currentSortField).toEqual('projectAbbreviation')
  })

  it('should toggleSortDirection', async () => {
    const store = useProposalStore()
    store.currentSortDirection = SortDirection.ASC
    await store.toggleSortDirection()
    expect(store.currentSortDirection).toEqual(SortDirection.DESC)
  })

  it('should create a publication', async () => {
    const store = useProposalStore()
    store.currentProposal = mockProposal
    jest.spyOn(proposalService, 'createPublication').mockResolvedValue([
      {
        title: 'string',
        doi: 'string',
        link: 'string',
        updatedAt: 'string',
        createdAt: 'string',
        _id: 'string',
      },
    ] as IPublicationGet[])
    const proposalId = '630dd9e8c8a548d21ef4c356'
    const publication = {
      title: 'string',
      doi: 'string',
      link: 'string',
    } as IPublicationCreateAndUpdate
    await store.createProposalPublication(proposalId, publication)
    expect(proposalService.createPublication).toHaveBeenCalledWith(proposalId, publication)
    expect(store.currentProposal.publications).toEqual([
      {
        title: 'string',
        doi: 'string',
        link: 'string',
        updatedAt: 'string',
        createdAt: 'string',
        _id: 'string',
      },
    ] as IPublicationGet[])
  })

  it('should update a publication', async () => {
    const store = useProposalStore()
    store.currentProposal = mockProposal
    jest.spyOn(proposalService, 'updatePublication').mockResolvedValue([
      {
        title: 'string',
        doi: 'string',
        link: 'string',
        updatedAt: 'string',
        createdAt: 'string',
        _id: 'string',
      },
    ] as IPublicationGet[])
    const proposalId = '630dd9e8c8a548d21ef4c356'
    const publicationId = ''
    const publication = {
      title: 'string',
      doi: 'string',
      link: 'string',
    } as IPublicationCreateAndUpdate
    await store.updateProposalPublication(proposalId, publicationId, publication)
    expect(proposalService.updatePublication).toHaveBeenCalledWith(proposalId, publicationId, publication)
    expect(store.currentProposal.publications).toEqual([
      {
        title: 'string',
        doi: 'string',
        link: 'string',
        updatedAt: 'string',
        createdAt: 'string',
        _id: 'string',
      },
    ] as IPublicationGet[])
  })

  it('should delete a publication', async () => {
    const store = useProposalStore()
    store.currentProposal = mockProposal
    jest.spyOn(proposalService, 'deletePublication').mockResolvedValue()
    const proposalId = '630dd9e8c8a548d21ef4c356'
    const publicationId = 'string'
    await store.deletePublication(proposalId, publicationId)
    expect(proposalService.deletePublication).toHaveBeenCalledWith(proposalId, publicationId)
    expect(store.currentProposal.publications).toEqual([] as IPublicationGet[])
  })

  it('should get reports', async () => {
    const store = useProposalStore()
    store.currentProposal = mockProposal
    jest.spyOn(proposalService, 'getReports').mockResolvedValue(mockProposal.reports)
    const proposalId = '630dd9e8c8a548d21ef4c356'
    await store.getReports(proposalId)
    expect(proposalService.getReports).toHaveBeenCalledWith(proposalId)
    expect(store.currentProposal.reports).toEqual(mockProposal.reports)
  })

  it('should get reports content', async () => {
    const store = useProposalStore()
    jest.spyOn(proposalService, 'getReportContent').mockResolvedValue('content')
    const proposalId = '630dd9e8c8a548d21ef4c356'
    const reportId = '1'
    await store.getReportContent(proposalId, reportId)
    expect(proposalService.getReportContent).toHaveBeenCalledWith(proposalId, reportId)
  })

  it('should create report', async () => {
    const store = useProposalStore()
    store.currentProposal = mockProposal
    jest.spyOn(proposalService, 'createReport').mockResolvedValue({
      title: 't',
      content: 'c',
      _id: '1',
      createdAt: '',
      updatedAt: '',
      uploads: [
        {
          downloadUrl: 'string',
          _id: 'string',
          fileName: 'string',
          fileSize: 1,
          type: UseCaseUpload.ReportUpload,
          mimetype: '',
          createdAt: 'string',
        },
      ],
    } as IReportGet)
    const proposalId = '630dd9e8c8a548d21ef4c356'
    const report = {
      _id: 'string',
      createdAt: 'string',
      updatedAt: 'string',
      uploads: [],
      files: [new Blob(['1'])],
    } as unknown as IReportCreate
    await store.createProposalReport(proposalId, report)
    expect(proposalService.createReport).toHaveBeenCalledWith(proposalId, report)
  })

  it('should update report', async () => {
    const store = useProposalStore()
    store.currentProposal = mockProposal
    jest.spyOn(proposalService, 'updateReport').mockResolvedValue({
      title: 't',
      content: 'c',
      _id: '2',
      createdAt: '',
      updatedAt: '',
      uploads: [
        {
          downloadUrl: 'string',
          _id: 'string',
          fileName: 'string',
          fileSize: 1,
          type: UseCaseUpload.ReportUpload,
          mimetype: '',
          createdAt: 'string',
        },
      ],
    } as IReportGet)
    const proposalId = '630dd9e8c8a548d21ef4c356'
    const report = {
      _id: 'string',
      createdAt: 'string',
      updatedAt: 'string',
      uploads: [],
      files: [new Blob(['1'])],
      keepUploads: [],
    } as unknown as IReportUpdate
    const reportId = '1'
    await store.updateProposalReport(proposalId, reportId, report)
    expect(proposalService.updateReport).toHaveBeenCalledWith(proposalId, reportId, report)
  })

  it('should delete a report', async () => {
    const store = useProposalStore()
    store.currentProposal = mockProposal
    jest.spyOn(proposalService, 'deleteReport').mockResolvedValue()
    const proposalId = '630dd9e8c8a548d21ef4c356'
    const reportId = '2'
    await store.deleteReport(proposalId, reportId)
    expect(proposalService.deleteReport).toHaveBeenCalledWith(proposalId, reportId)
    expect(store.currentProposal.reports).toEqual([])
  })

  it('should update checklist', async () => {
    const store = useProposalStore()
    store.currentProposal = mockProposal

    jest.spyOn(proposalService, 'updateFdpgChecklist').mockResolvedValue()
    const proposalId = '630dd9e8c8a548d21ef4c356'
    await store.updateFdpgChecklist(proposalId, [{}] as IFdpgChecklist, undefined)
    await store.updateFdpgChecklist(proposalId, [{}] as IFdpgChecklist, undefined)
    jest.advanceTimersByTime(1000)
    expect(store.currentProposal.fdpgChecklist).toEqual({ ...[{}] })
    expect(proposalService.updateFdpgChecklist).toHaveBeenCalledWith(proposalId, [{}] as IFdpgChecklist)
    expect(proposalService.updateFdpgChecklist).toHaveBeenCalledTimes(1)
  })

  it('should call checklist with an error', async () => {
    const store = useProposalStore()
    store.currentProposal = mockProposal

    const proposalId = '630dd9e8c8a548d21ef4c356'
    const errorCb = jest.fn().mockImplementation((error) => error)
    jest.spyOn(proposalService, 'updateFdpgChecklist').mockRejectedValue('error')

    await store.updateFdpgChecklist(proposalId, [{}] as IFdpgChecklist, errorCb)
    jest.advanceTimersByTime(10000)

    const flushPromises = () => new Promise(setImmediate)
    await flushPromises()

    expect(errorCb).toHaveBeenCalledTimes(1)
  })

  it('should check the getter', async () => {
    const store = useProposalStore()
    store.proposals = { [PanelQuery.Archived]: [mockProposalDetail] }
    store.search = '  ShortCut  '
    expect(store.filteredProposal).toEqual({ ARCHIVED: [mockProposalDetail] })
    store.search = '  ownerName  '
    expect(store.filteredProposal).toEqual({ ARCHIVED: [mockProposalDetail] })
    store.search = '  projectTitle  '
    expect(store.filteredProposal).toEqual({ ARCHIVED: [mockProposalDetail] })
    store.search = ''
    expect(store.filteredProposal).toEqual(store.proposals)
  })
})
