import { useFeasibilityStore } from './feasibility.store'
import { FeasibilityService } from '@/services/feasibility/feasibility.service'
import { createPinia, setActivePinia } from 'pinia'
import { IFeasibilityDetail } from '@/types/feasibility-detail.interface'

jest.mock('@/services/feasibility/feasibility.service')

const feasibilityService = jest.mocked(new FeasibilityService())

describe('Feasibility Store', () => {
  beforeEach(() => {
    jest.clearAllMocks()
    setActivePinia(createPinia())
  })

  it('renders', () => {
    const store = useFeasibilityStore()
    expect(store).toBeTruthy()
  })

  describe('GetAll', () => {
    it('should call the service to get all feasibility', async () => {
      const store = useFeasibilityStore()
      jest.spyOn(feasibilityService, 'getAll').mockResolvedValue([
        {
          id: 2,
          label: 'string',
          createdAt: 'string',
        },
      ] as IFeasibilityDetail[])
      await store.getAll()
      expect(feasibilityService.getAll).toHaveBeenCalledTimes(1)
      expect(store.feasibilityQueries).toEqual([
        {
          id: 2,
          label: 'string',
          createdAt: 'string',
        },
      ] as IFeasibilityDetail[])
    })
  })
})
