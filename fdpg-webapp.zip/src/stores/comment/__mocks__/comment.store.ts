const mockFetchAll = jest.fn()
const mockCreateComment = jest.fn()
const mockCreateAnswer = jest.fn()
const mockMarkCommentAsDone = jest.fn()
const mockMarkAnswerAsDone = jest.fn()
const mockUpdateComment = jest.fn()
const mockDeleteComment = jest.fn()

export const useCommentStore = jest.fn().mockImplementation(() => ({
  comments: [],

  //Actions
  fetchAll: mockFetchAll,
  createComment: mockCreateComment,
  createAnswer: mockCreateAnswer,
  markCommentAsDone: mockMarkCommentAsDone,
  markAnswerAsDone: mockMarkAnswerAsDone,
  updateComment: mockUpdateComment,
  deleteComment: mockDeleteComment,

  //Getters
  commentsObj: {},
}))
