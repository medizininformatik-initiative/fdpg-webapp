const mockGetTermsAndConditions = jest.fn()

export const useCommentStore = jest.fn().mockImplementation(() => ({
  termsAndConditions: {},

  //Actions
  getTermsAndConditions: mockGetTermsAndConditions,
}))
