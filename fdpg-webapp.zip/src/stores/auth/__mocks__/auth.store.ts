import { Role } from '@/types/oidc.types'

const mockLogIn = jest.fn()
const mockLogOut = jest.fn()

export const useAuthStore = jest.fn().mockImplementation(() => ({
  $oidc: {},

  //Actions
  logIn: mockLogIn,
  logOut: mockLogOut,

  //Getters
  profile: {},
  roles: {},
  singleKnownRole: Role.FdpgMember,
  isLoggedIn: true,
  token: 'accessToken',
}))
