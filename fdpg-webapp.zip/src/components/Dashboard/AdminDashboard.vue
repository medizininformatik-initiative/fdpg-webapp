<template>
  <div class="fdpg-dashboard-page"></div>
</template>

<script setup lang="ts"></script>
