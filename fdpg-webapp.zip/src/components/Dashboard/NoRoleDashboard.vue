<template>
  <section>{{ $t('dashboard.noRole') }}</section>
</template>

<script setup lang="ts"></script>
