import { useProposalStore } from '@/stores/proposal/proposal.store'
import { RouteName } from '@/types/route-name.enum'
import { createTestingPinia } from '@pinia/testing'
import { shallowMount, VueWrapper } from '@vue/test-utils'
import FdpgMemberDashboard from '../FdpgMemberDashboard.vue'
import FdpgSortSelect from '@/components/FdpgSortSelect.vue'

jest.mock('vue-i18n', () => ({
  useI18n: jest.fn().mockImplementation(() => ({
    t: jest.fn().mockReturnValue('Test'),
    locale: {
      value: 'de-DE',
    },
  })),
}))

const mockRoute = RouteName.Dashboard
const mockPush = jest.fn()
jest.mock('vue-router', () => ({
  useRoute: jest.fn(() => mockRoute),
  useRouter: jest.fn(() => ({
    push: mockPush,
  })),
}))

describe('FdpgMemberDashboard.vue', () => {
  let wrapper: VueWrapper<any>
  let proposalStore: jest.MockedObject<ReturnType<typeof useProposalStore>>

  beforeEach(() => {
    wrapper = shallowMount(FdpgMemberDashboard, {
      global: {
        plugins: [createTestingPinia()],
        stubs: [],
      },
    })
  })

  beforeEach(() => {
    proposalStore = jest.mocked(useProposalStore())
  })

  it('renders', () => {
    expect(wrapper).toBeTruthy()
  })

  it('calls the proposalStore to handle the sort order change', () => {
    const selectElement = wrapper.findComponent(FdpgSortSelect)
    selectElement.vm.$emit('sortOrderChange')
    expect(proposalStore.toggleSortDirection).toHaveBeenCalledTimes(1)
  })

  it('calls the proposalStore to handle the sort change', () => {
    const selectElement = wrapper.findComponent(FdpgSortSelect)
    selectElement.vm.$emit('sortChange', 'test')
    expect(proposalStore.setSortField).toHaveBeenLastCalledWith('test')
  })

  it('calls the router to go to the detail page', () => {
    const id = 'abc'
    wrapper.vm.handleRowClick({ id, somethingElse: 'test' })
    expect(mockPush).toBeCalledWith({ name: RouteName.ProposalDetails, params: { id } })
  })
})
