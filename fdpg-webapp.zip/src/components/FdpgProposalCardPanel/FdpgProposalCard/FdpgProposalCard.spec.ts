import { useAuthStore } from '@/stores/auth/auth.store'
import { CardType } from '@/types/component.types'
import { shallowMount, VueWrapper } from '@vue/test-utils'
import FdpgProposalCard from './FdpgProposalCard.vue'
import { createTestingPinia } from '@pinia/testing'
import { mockProposalDetail } from '@/mocks/proposal.mock'

jest.mock('vue-i18n', () => ({
  useI18n: jest.fn().mockImplementation(() => ({
    t: jest.fn().mockReturnValue('Test'),
    locale: {
      value: 'de-DE',
    },
  })),
}))

jest.mock('vue-router', () => ({
  useRouter: jest.fn(() => ({
    push: jest.fn(),
  })),
}))

let authStore: ReturnType<typeof useAuthStore>

describe('FdpgProposalCard.vue', () => {
  let wrapper: VueWrapper<any>

  beforeEach(() => {
    wrapper = shallowMount(FdpgProposalCard, {
      props: {
        proposal: mockProposalDetail,
        type: CardType.Pending,
      },
      global: {
        plugins: [createTestingPinia()],
        stubs: ['el-col', 'el-row', 'el-progress'],
      },
    })
  })

  beforeEach(() => {
    authStore = jest.mocked(useAuthStore())
  })

  it('renders', () => {
    expect(wrapper).toBeTruthy()
  })
})
