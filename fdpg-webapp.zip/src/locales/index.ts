import en from './en.json'
import de from './de.json'

export { en, de }
