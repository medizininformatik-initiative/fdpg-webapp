export class LocationUtil {
  location = window.location
  protocol = this.location.protocol
  host = this.location.host
  basePath = process.env.VUE_APP_BASE_PATH
  baseUrl = `${this.protocol}//${this.host}${this.basePath ? this.basePath : '/'}`
}
