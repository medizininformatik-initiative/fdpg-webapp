import { proposalCountMock } from '@/mocks/proposal-counts.mock'
import { useProposalStore } from '@/stores/proposal/proposal.store'
import { createTestingPinia } from '@pinia/testing'
import { setActivePinia } from 'pinia'
import useNotifications from '../use-notifications'
import { ElNotification } from 'element-plus'

jest.mock('vue-i18n', () => ({
  useI18n: jest.fn().mockImplementation(() => ({
    t: jest.fn().mockImplementation((key: string) => key),
    locale: {
      value: 'de-DE',
    },
  })),
}))

jest.mock('element-plus', () => ({
  ElNotification: jest.fn().mockImplementation(() => ({})),
}))

describe('UseNotifications', () => {
  let proposalStore: jest.MockedObject<ReturnType<typeof useProposalStore>>
  beforeEach(() => {
    jest.clearAllMocks()
    setActivePinia(createTestingPinia())
    jest.useFakeTimers()
    proposalStore = jest.mocked(useProposalStore())
    proposalStore.counts = proposalCountMock
  })

  it('should call notification function if something is wrong', () => {
    const { showErrorMessage } = useNotifications()
    showErrorMessage()
    expect(ElNotification).toBeCalledWith({ title: 'Error', message: 'general.genericError', type: 'error' })
  })

  it('should call notification function if something is wrong', () => {
    const { showSuccessMessage } = useNotifications()
    showSuccessMessage()
    expect(ElNotification).toBeCalledWith({ title: 'Success', message: 'general.submitted', type: 'success' })
  })

  it('should call notification function if receive message', () => {
    const { showSuccessMessage } = useNotifications()
    showSuccessMessage('messageReceived')
    expect(ElNotification).toBeCalledWith({ title: 'Success', message: 'messageReceived', type: 'success' })
  })

  it('should call notification function if receive message', () => {
    const { showErrorMessage } = useNotifications()
    showErrorMessage('messageReceived')
    expect(ElNotification).toBeCalledWith({ title: 'Error', message: 'messageReceived', type: 'error' })
  })

  it('should call notification function if receive array of messages', () => {
    const { showErrorMessage } = useNotifications()
    const messages = ['hey', 'bye']

    showErrorMessage(messages)
    jest.advanceTimersByTime(100 * (messages.length - 1) + 2)
    expect(ElNotification).toBeCalledTimes(messages.length)
  })
})
