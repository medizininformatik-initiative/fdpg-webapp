import { AxiosError, AxiosRequestConfig, AxiosResponse } from 'axios'
import { useAuthStore } from '@/stores/auth/auth.store'

const requestInterceptor = {
  onFullfilled: (config: AxiosRequestConfig<any>) => {
    const auth = useAuthStore()
    const token = auth.token
    if (token) {
      const authHeader = {
        Authorization: `Bearer ${token}`,
      }
      config.headers = {
        ...config.headers,
        ...authHeader,
      }
    }

    return Promise.resolve(config)
  },

  onRejected: (error: AxiosError) => Promise.reject(error),
}

const responseInterceptor = {
  onFullfilled: (response: AxiosResponse<any, any>) => response,
  onRejected: (error: AxiosError) => {
    const auth = useAuthStore()

    if (error.response?.status === 401 && auth.isLoggedIn) {
      auth.logOut()
    }

    return Promise.reject(error)
  },
}

export { requestInterceptor, responseInterceptor }
