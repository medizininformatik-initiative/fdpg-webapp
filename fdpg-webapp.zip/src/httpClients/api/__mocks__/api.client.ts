const mockGet = jest.fn().mockImplementation(() => Promise.resolve())
const mockPost = jest.fn().mockImplementation(() => Promise.resolve())
const mockPut = jest.fn().mockImplementation(() => Promise.resolve())
const mockPatch = jest.fn().mockImplementation(() => Promise.resolve())
const mockDelete = jest.fn().mockImplementation(() => Promise.resolve())

export const ApiClient = jest.fn().mockImplementation(() => ({
  client: {
    get: mockGet,
    post: mockPost,
    put: mockPut,
    patch: mockPatch,
    delete: mockDelete,
  },
}))
